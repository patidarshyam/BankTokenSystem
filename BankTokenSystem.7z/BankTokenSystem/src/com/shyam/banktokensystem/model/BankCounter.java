package com.shyam.banktokensystem.model;

public class BankCounter {
	
	private int counterNumber;
	
	private boolean occupied;
	
	private int customerId;
	
	public BankCounter() {
		
	}

	public BankCounter(int counterNumber, boolean occupied) {
		super();
		this.counterNumber = counterNumber;
		this.occupied = occupied;
	}
	

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getCounterNumber() {
		return counterNumber;
	}

	public void setCounterNumber(int counterNumber) {
		this.counterNumber = counterNumber;
	}

	public boolean isOccupied() {
		return occupied;
	}

	public void setOccupied(boolean occupied) {
		this.occupied = occupied;
	}

	@Override
	public String toString() {
		return "BankCounter [counterNumber=" + counterNumber + ", occupied=" + occupied + ", customerId=" + customerId
				+ "]";
	}

	

}
