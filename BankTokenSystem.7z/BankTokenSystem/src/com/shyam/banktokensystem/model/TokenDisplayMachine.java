package com.shyam.banktokensystem.model;

public class TokenDisplayMachine {
	
	private int tokenId;
	
	private int bankCounterNumber;
	

	public TokenDisplayMachine(int tokenId, int bankCounterNumber) {
		super();
		this.tokenId = tokenId;
		this.bankCounterNumber = bankCounterNumber;
	}

	public int getTokenId() {
		return tokenId;
	}

	public void setTokenId(int tokenId) {
		this.tokenId = tokenId;
	}

	public int getBankCounterNumber() {
		return bankCounterNumber;
	}

	public void setBankCounterNumber(int bankCounterNumber) {
		this.bankCounterNumber = bankCounterNumber;
	}

	@Override
	public String toString() {
		return "TokenDisplayMachine [tokenId=" + tokenId + ", bankCounterNumber=" + bankCounterNumber + "]";
	}
	

}
