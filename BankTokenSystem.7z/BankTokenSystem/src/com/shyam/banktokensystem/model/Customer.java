package com.shyam.banktokensystem.model;

public class Customer {
	
	private int customerId;
	
	private String name;
	
	private boolean priviledgedCustomer;
	
	public Customer() {}
	

	public Customer(int id, String name, boolean priviledgedCustomer) {
		super();
		this.customerId = id;
		this.name = name;
		this.priviledgedCustomer = priviledgedCustomer;
	}



	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int id) {
		this.customerId = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isPriviledgedCustomer() {
		return priviledgedCustomer;
	}

	public void setPriviledgedCustomer(boolean priviledgedCustomer) {
		this.priviledgedCustomer = priviledgedCustomer;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + customerId;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + (priviledgedCustomer ? 1231 : 1237);
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (customerId != other.customerId)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (priviledgedCustomer != other.priviledgedCustomer)
			return false;
		return true;
	}
	
	

}
