package com.shyam.banktokensystem.model;

public class Token {
	
	private int tokenId;
	
	private int customerId;
	
	public Token() {}

	public Token(int tokenId, int customerId) {
		super();
		this.tokenId = tokenId;
		this.customerId = customerId;
	}

	public int getTokenId() {
		return tokenId;
	}

	public void setTokenId(int tokenId) {
		this.tokenId = tokenId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "Token [tokenId=" + tokenId + ", customerId=" + customerId + "]";
	}
	
	

}
