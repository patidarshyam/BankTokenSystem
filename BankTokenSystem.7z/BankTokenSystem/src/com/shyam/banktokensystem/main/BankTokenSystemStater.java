package com.shyam.banktokensystem.main;

import java.util.HashMap;

import com.shyam.banktokensystem.model.BankCounter;
import com.shyam.banktokensystem.model.Customer;
import com.shyam.banktokensystem.service.TokenService;

public class BankTokenSystemStater {

	public static void main(String[] args) {

		TokenService tokenService=new TokenService();
		
		Customer customer10 = new Customer(1001, "Shyam p", true);
		Customer customer100 = new Customer(10001, "Shyam pp", true);
		
		Customer customer2 = new Customer(102, "patidar", false);
		Customer customer3 = new Customer(103, "Neha", false);
		Customer customer20 = new Customer(1029, "patidar", false);
		Customer customer30 = new Customer(1039, "Neha", false);
		Customer customer200 = new Customer(10208, "patidar", false);
		Customer customer300 = new Customer(1037, "Neha", false);
		
		
		System.out.println(tokenService.getToken(customer2));
		System.out.println(tokenService.getToken(customer3));
		
		System.out.println(tokenService.getToken(customer10));
		System.out.println(tokenService.getToken(customer20));
		System.out.println(tokenService.getToken(customer30));
		System.out.println("--------------------");

		HashMap<Integer, BankCounter> bankCounters=tokenService.displayToken();
		
		tokenService.makeCounterFree(bankCounters.get(1));//releasing the counter
		tokenService.makeCounterFree(bankCounters.get(3));
		
		System.out.println(tokenService.getToken(customer100));
		System.out.println(tokenService.getToken(customer200));
		System.out.println(tokenService.getToken(customer300));
		System.out.println("--------------------");
		HashMap<Integer, BankCounter> bankCounters1=tokenService.displayToken();
		////////////////////////////////////////
		Customer customer01 = new Customer(1010, "Shyam", false);
		Customer customer02 = new Customer(1020, "patidar", true);
		Customer customer03 = new Customer(1030, "Neha", false);
		
		System.out.println(tokenService.getToken(customer01));
		System.out.println(tokenService.getToken(customer02));
		System.out.println(tokenService.getToken(customer03));
		
		tokenService.makeCounterFree(bankCounters.get(1));//releasing the counter
		tokenService.makeCounterFree(bankCounters.get(3));
		tokenService.makeCounterFree(bankCounters.get(2));//releasing the counter
		
		tokenService.displayToken();
		
		
	}

}
 