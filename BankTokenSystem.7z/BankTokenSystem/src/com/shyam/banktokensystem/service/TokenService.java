package com.shyam.banktokensystem.service;

import java.util.HashMap;
import com.shyam.banktokensystem.model.BankCounter;
import com.shyam.banktokensystem.model.Customer;
import com.shyam.banktokensystem.model.Token;
import com.shyam.banktokensystem.model.TokenDisplayMachine;

public class TokenService {
	//Token number Start from 10 to 100
	private HashMap<Integer, Customer> tokens;
	//Token number from 1 to 10
	private HashMap<Integer, Customer> privilegedCustomerTokens;
	//Only 5 counters in a bank	
	private HashMap<Integer,BankCounter> bankCounters;
	
	public TokenService() {
		tokens=new HashMap<>();
		privilegedCustomerTokens= new HashMap<>();
		bankCounters=new HashMap<>(5);
		
		bankCounters.put(1, new BankCounter(1, false));
		bankCounters.put(2,new BankCounter(2, false));
		bankCounters.put(3, new BankCounter(3, false));
		bankCounters.put(4, new BankCounter(4, false));
		bankCounters.put(5, new BankCounter(5, false));
	}
	
	public HashMap<Integer, Customer> getTokens() {
		return tokens;
	}
	public void setTokens(HashMap<Integer, Customer> tokens) {
		this.tokens = tokens;
	}

	public HashMap<Integer, Customer> getPriviledgedCustomerTokens() {
		return privilegedCustomerTokens;
	}
	public void setPriviledgedCustomerTokens(HashMap<Integer, Customer> priviledgedCustomerTokens) {
		this.privilegedCustomerTokens = priviledgedCustomerTokens;
	}
	public HashMap<Integer, BankCounter> getBankCounters() {
		return bankCounters;
	}
	public void setBankCounters(HashMap<Integer, BankCounter> bankCounters) {
		this.bankCounters = bankCounters;
	}

	int lastTokenId=10;
	int lastPreCustomerTokenId=0;
	/**
	 * This method will generate the token for the new customer who came into bank.
	 * if customer is privileged then token number is between 1 to 10
	 * else token number is in between 11 to 100
	 * @param customer
	 * @return
	 */
	public Token getToken(Customer customer) {
		if(customer.isPriviledgedCustomer()) {
			for(int i=1; i<=10; i++) {
				if(privilegedCustomerTokens.get(i)==null) {
					privilegedCustomerTokens.put(i, customer);
					return new Token(i, customer.getCustomerId());
				}
			}		
		}else {
			for(int i=11; i<=100; i++) {
				if(tokens.get(i)==null) {
					tokens.put(i, customer);
					return new Token(i, customer.getCustomerId());
				}
			}
		}
		return null;	
	}
	
	/**
	 * This method display on the display machine with TokenId and BankCounter number
	 * @return
	 */
	public HashMap<Integer,BankCounter> displayToken() {
		// If priviledgedCustomerTokens are in queue
		if(privilegedCustomerTokens!=null)
			displayPriviledgedToken();
		
		if(tokens!=null)
			displayNormalCustomer();
		
		return bankCounters;
	}

/**
 * This method will display the normal customer's counter number
 */
	private void displayNormalCustomer() {
		for(Integer tokenId:tokens.keySet()){
				for(int counter:bankCounters.keySet()) {
					if(bankCounters.get(counter).isOccupied() && bankCounters.get(counter).getCustomerId()==tokens.get(tokenId).getCustomerId())
						break;
					if(!bankCounters.get(counter).isOccupied()) {
						
						System.out.println(new TokenDisplayMachine(tokenId, bankCounters.get(counter).getCounterNumber())+" \n--for customer ->"+tokens.get(tokenId).getCustomerId());
						BankCounter tempCounter= bankCounters.get(counter);
						tempCounter.setOccupied(true);
						tempCounter.setCustomerId(tokens.get(tokenId).getCustomerId());
						bankCounters.put(counter, tempCounter);
						
						break;
					}
				}
			}
	}

	/**
	 * This method will display the privileged customer's counter number
	 */
	private void displayPriviledgedToken() {
		for(Integer tokenId:privilegedCustomerTokens.keySet()){
			for(int counter:bankCounters.keySet()) {
				if(bankCounters.get(counter).isOccupied() && bankCounters.get(counter).getCustomerId()==privilegedCustomerTokens.get(tokenId).getCustomerId())
					break;
				if(!bankCounters.get(counter).isOccupied()) {
					
					System.out.println(new TokenDisplayMachine(tokenId, bankCounters.get(counter).getCounterNumber())+" \n--for customer ->"+privilegedCustomerTokens.get(tokenId).getCustomerId());
					BankCounter tempCounter= bankCounters.get(counter);
					tempCounter.setCustomerId(privilegedCustomerTokens.get(tokenId).getCustomerId());
					tempCounter.setOccupied(true);
					bankCounters.put(counter, tempCounter);
					
					break;
				}
			}
				
		}
	}
	/**
	 * This method shows that the work of the customer is completed so counter is free now and ready for another customer's work.
	 * @param bankCounter
	 */
	public void makeCounterFree(BankCounter bankCounter) {
		
		int removeId=0;
		boolean checked=false;
		for(int cust:privilegedCustomerTokens.keySet()) {
			if(privilegedCustomerTokens.get(cust).getCustomerId()==bankCounter.getCustomerId()) {
				removeId=cust;
				checked=true;
			}
		}
		if(!checked) {
			for(int token:tokens.keySet()) {
				if(tokens.get(token).getCustomerId()==bankCounter.getCustomerId()) {
					removeId=token;
				}
			}
		}
		
		
		if(!bankCounter.isOccupied()) 
			System.out.println("Counter number "+bankCounter.getCounterNumber()+" is already free ");
		else {
			bankCounter.setOccupied(false);
			bankCounter.setCustomerId(0);
			System.out.println("Counter"+bankCounter.getCounterNumber()+" is free...!!!");
		}
		
		if(privilegedCustomerTokens.containsKey(removeId)) {
			privilegedCustomerTokens.remove(removeId);
		}else if(tokens.containsKey(removeId)) {
			tokens.remove(removeId);
		}
		
	}
}
